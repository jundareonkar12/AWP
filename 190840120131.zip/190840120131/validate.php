<?php
   session_start();
//echo "working fine";
$servername = "localhost";
$username = "root";
$password = "actscdac";
$dbname= "myphp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo "error while connecting";
}
echo "Connected successfully";
$email=$_POST["email"];
$pass=$_POST["pass"];
//echo "<br>";
//echo $email;
echo "<br>";
//echo $pass;

$query="select * from employee where email='$email' and password='$pass'";
$result=$conn->query($query);
echo "<br>";
if($result->num_rows>0)
{
 
    $_SESSION["emailid"]="$email";
    echo "  <h2 style='color: green; '>Login_Sucessful</h2>    ";  

}
else{
    echo "<h2>wrong pass</h2>";
}
?>